<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <?php
        include"header.php";
    ?>
        <?php
       session_start();
        $_SESSION["u"]="";
        header("location:../adminlogin.php");
        
        ?>
        
        <h1>You have been successfully Logout</h1>
    </body>
</html>