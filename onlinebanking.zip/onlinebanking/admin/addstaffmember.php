<html>
<head>
    <title>Add Staff</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
        <form action="addstaffmember.php"method="POST">
    <?php
        include"header.php";
    ?>
            <center>
            <div class="login">
                <table>
                    <h2>Add Staff</h2>
                    <hr/>
                    <tr>
                    <td>Name</td>
                        <td><input type="text"name="txtname"></td>
                    </tr>     
                    <tr>
                    <td>Deptt</td>
                        <td><input type="text"name="txtdeptt"></td>
                    </tr>     
                    <tr>
                    <td>Address</td>
                        <td><input type="text"name="txtadd"></td>
                    </tr> 
                        
                    <tr>
                    <td>Login ID</td>
                        <td><input type="text"name="user"></td>
                    </tr> 
                        
                    <tr>
                    <td>Password</td>
                        <td><input type="password"name="pass"></td>
                    </tr> 
                    <tr>
                    <td><input type="submit"name="submit"value="ADD"</td>
                    </tr>

                </table>
                </div>
            </center>
            </form>
        <?php
          if(!isset($_POST["submit"]))
        {
            
        }
        else if($_POST["submit"]=="ADD")
        {
            $name=$_POST["txtname"];
            $deptt=$_POST["txtdeptt"];
             $add=$_POST["txtadd"];
             $user=$_POST["user"];
            $pass=$_POST["pass"];
             $con=mysqli_connect("localhost","root","","netbanking");
            $sql="insert into addstaff(login_id,password,name,deptt,address,status)values('$user','$pass','$name','$deptt','$add','UNBLOCK')";
            mysqli_query($con,$sql);
            mysqli_close($con);
            echo "<h1>added</h1>";
        }
        
        
        ?>
    </body>
    
</html>   