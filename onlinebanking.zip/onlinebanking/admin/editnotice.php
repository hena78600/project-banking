<html>
<head>
    <title>Show</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <form action="editnotice.php"method="POST">
        <?php
        include "header.php";
        
        ?>
         <?php
        $noti_id="";
        $noti_details="";
        if(isset($_GET["nid"]))
        {
            $noti_id=$_GET["nid"];
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select notificationid,notificationdetails from addnotification where notificationid=$noti_id";
        
            $result=mysqli_query($con,$sql);
            while($row=mysqli_fetch_row($result))
        {
                $noti_id=$row[0];
                $noti_details=$row[1];        
        
        }
            mysqli_close($con);
        }
        ?>
        <table>
            <tr>
            <td><input type="hidden"name="txthidden" value="<?php echo "$noti_id"?>"></td>
            </tr>
            
        <tr>
            <td>notification_details</td>
            <td><textarea cols="4"rows="4" name="txtnoti" ><?php echo $noti_details ?>  </textarea></td>
            </tr>
        <tr><td><input type="submit"name="submit" value="Update"></td>
            <td><input type="submit" name="submit" value="Delete"></td>
            </tr>
        
        
        </table>
        </form>
        <?php
        if(!isset($_POST["submit"]))
        {
            
        }
    else if($_POST["submit"]=="Update")
    {
        $hidden_id=$_POST["txthidden"];
        $noti_details=$_POST["txtnoti"];
        $con=mysqli_connect("localhost","root","","netbanking");
        $sql="update addnotification set notificationdetails='$noti_details' where notificationid=$hidden_id";
        
        mysqli_query($con,$sql);
        mysqli_close($con);
        
        echo "<h1> Notice Updated Successfully</h1>";
    }
     else if($_POST["submit"]=="Delete") 
     {
         $hidden_id=$_POST["txthidden"];
         $con=mysqli_connect("localhost","root","","netbanking");
         $sql="delete from addnotification where notificationid=$hidden_id";
         mysqli_query($con,$sql);
         mysqli_close($con);
         echo "notice deleted successfully";
         
     }
        
        
        
        
        ?>
   </body>
</html>