<html>
<head>
    <title>Customer's Notification</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <?php
        include"header.php";
    ?>
        <?php
        $name="";
        $fatname="";
        $gender="";
        $adhaar="";
        $mobile="";
        $email="";
        $dob="";
        $addrees="";
        $bankname="";
        $branch="";
        $type="";
        if(!isset($_POST["submit"]))
        {
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select id,name,fname,gender,adhaar,mobile,email,dob,address,bankname,branch,type,image,status from registration";
            
            $result=mysqli_query($con,$sql);
            $table="";
            $table=$table."<table border='2'>
            <caption><h1><u>Customer's Details</u></h1></caption>
            <tr style='background-color:salmon'>
            
            <th>id</th>
            <th> name</th>
            <th> Father Name</th>
            <th>Gender</th>
            <th>Adhaar Number</th>
            <th>Mobile Number</th>
            <th>Email Id</th>
            <th>Date Of Birth</th>
            <th>Address</th>
            <th>Bank Name</th>
            <th>Branch</th>
            <th>Type Of Account</th>
            <th>Image</th>
            <th> Status</th></tr>";
            while($row=mysqli_fetch_row($result))
            {
                $table=$table."<tr><td>$row[0]</td>
                <td>$row[1]</td>
                <td>$row[2]</td>
                <td>$row[3]</td>
                <td>$row[4]</td>
                <td>$row[5]</td>
                <td>$row[6]</td>
                <td>$row[7]</td>
                <td>$row[8]</td>
                <td>$row[9]</td>
                <td>$row[10]</td>
                <td>$row[11]</td>
                <td><img src='../$row[12]' height='50px' width='50px'></td>
                <td><a href='block.php?id=$row[0]'>$row[13]</a></td></tr>";
            }
            $table=$table."</table>";
            echo $table;
        }
        
        ?>
        
    </body>
</html>