<html>
<head>
    <title>Customer's Notification</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    
    <?php
        include"header.php";
    ?>
        <form action="loan_block.php"method="POST">   
            <?php
            $lid="";
        if(isset($_GET["lid"]))
        {
            $lid=$_GET["lid"];
            
       include "../connect.php";
            $sql="select loanid,account_no,bankname,branchname,loanamount,loantype,status from loan_details where loanid='$lid'";
            
            
            
           $result=mysqli_query($con,$sql);
            $table="";
             $table=$table."<h1><u><center>Approve/Discard Loan</center></u></h1>";
            $table=$table."<table cellpadding='4' style='border:2px solid black' align='center'>";
           
            
            
            while($row=mysqli_fetch_row($result))
            {
                $table=$table."<tr><td>Account Number</td>
                <td>$row[1]</td></tr>
                <tr><td>Bank Name</td>
                <td>$row[2]</td></tr>
                
                <tr><td>Branch </td>
                <td>$row[3]</td></tr>
                <tr><td>Loan Amount</td>
                <td>$row[4]</td></tr>
                <tr><td> Type Of the Loan</td>
                <td>$row[5]</td></tr>
                
                
                <tr><td>STATUS</td>
                <td>$row[6]</td></tr>
                <tr>
                <td>Change Status</td>
                <td><select name='loan_status'><option>Select</option><option>APPROVE</option><option>PENDING</option></td>
                
                <tr><td></td>
                <td><input type='submit' name='submit'value='ALLOW'></td></tr>";
            }
            $table=$table."</table>";
            echo $table;
        }
        
        ?>
        <input type="hidden"name="hdid"value="<?php echo "$lid"?>">

        </form>
        <?php
    if(!isset($_POST["submit"]))
    {
        
    }
    else if($_POST["submit"]=="ALLOW")
    {
        $loan_id=$_POST["hdid"];
        $status=$_POST["loan_status"];
        include "../connect.php";
        $sql="update loan_details set status='$status' where loanid=$loan_id";
        
        mysqli_query($con,$sql);
        mysqli_close($con);
        echo "<h1>Status Changed Successfully</h1>";
    }
    
    
    
    
    
    ?>
    </body>
    