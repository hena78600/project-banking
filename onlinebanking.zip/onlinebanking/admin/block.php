<html>
<head>
    <title>Customer's Notification</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    
    <?php
        include"header.php";
    ?>
        <form action="block.php"method="POST">   
            <?php
            $cid="";
        if(isset($_GET["id"]))
        {
            $cid=$_GET["id"];
            
       include "../connect.php";
            $sql="select id,name,fname,gender,adhaar,mobile,email,dob,address,bankname,branch,type,status, max(account_no)+1 from registration where id='$cid'";
            
            
            
           $result=mysqli_query($con,$sql);
            $table="";
             $table=$table."<h1><u><center>Change Customer's Status</center></u></h1>";
            $table=$table."<table cellpadding='4' style='border:2px solid black' align='center'>";
           
            
            
            while($row=mysqli_fetch_row($result))
            {
                $table=$table."<tr><td>CUSTOMER NAME:</td>
                <td>$row[1]</td></tr>
                <tr><td>GENDER</td>
                <td>$row[3]</td></tr>
                
                <tr><td>AADHAAR NUMBER</td>
                <td>$row[4]</td></tr>
                <tr><td>MOBILE NUMBER</td>
                <td>$row[5]</td></tr>
                <tr><td>EMAIL ID</td>
                <td>$row[6]</td></tr>
                <tr><td>BANK NAME</td>
                <td>$row[9]</td></tr>
                <tr><td>BRANCH</td>
                <td>$row[10]</td></tr>
                <tr><td>STATUS</td>
                <td>$row[12]</td></tr>
                <tr>
                <td>Add Account No</td>
                <td><input type='text' name='nm' value='$row[13]'></td></tr>
                <tr>
                <td>Change Status</td>
                <td><select name='cust_status'><option>Select</option><option>BLOCK</option><option>UNBLOCK</option></td>
                
                <tr><td></td>
                <td><input type='submit' name='submit'value='CHANGE'></td></tr>";
            }
            $table=$table."</table>";
            echo $table;
        }
        
        ?>
                            <input type="hidden"name="hdid"value="<?php echo "$cid"?>">

        </form>
        <?php
    if(!isset($_POST["submit"]))
    {
        
    }
    else if($_POST["submit"]=="CHANGE")
    {
        $acc_no=$_POST["nm"];
        $cust_id=$_POST["hdid"];
        $status=$_POST["cust_status"];
        include "../connect.php";
        $sql="update registration set status='$status', account_no='$acc_no' where id=$cust_id";
        mysqli_query($con,$sql);
        mysqli_close($con);
        echo "<h1>Status Changed Successfully</h1>";
    }
    
    
    
    
    
    ?>
    </body>
    