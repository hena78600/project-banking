<html>
<head>
    <title>Add Staff</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <?php
        include"header.php";
    ?>
            <?php
            $name="";
            $deptt="";
            $address="";
             if(!isset($_POST["submit"]))
        {
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select id,name,deptt,address from addstaff";
            
            $result=mysqli_query($con,$sql);
            $table="";
            $table=$table."<table border='2'>
            <caption><h1><u>Staff's Details</u></h1></caption>
            <tr style='background-color:salmon'>
            
            <th>id</th>
            <th> name</th>
            <th> Deptt</th>
            <th>Address</th>";
            while($row=mysqli_fetch_row($result))
            {
                $table=$table."<tr><td><input type='radio' name='idrd'>$row[0]</td>
                <td>$row[1]</td>
                <td>$row[2]</td>
                <td>$row[3]</td></tr>
                <tr>
            <td><a href='deletestaffmember.php?sid=$row[0]'>DELETE</a></td>
            
                </tr>";
            }
            $table=$table."</table>";
            echo $table;
        }
            ?>
        <table>
        </table>
        
    </body>
</html>   