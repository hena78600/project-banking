<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
   <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section --> 
    
    
    
    
    
    
    </head>
    <body>
        <form action="adminhome.php"method="POST">
    <?php
        include"header.php";
    ?>
            <div class='slide'>
          <!-- Start WOWSlider.com BODY section -->
<div id="wowslider-container1">
<div class="ws_images"><ul>
		<li><img src="data1/images/img.jpg" alt="img" title="img" id="wows1_0"/></li>
		<li><img src="data1/images/img1.jpg" alt="img1" title="img1" id="wows1_1"/></li>
		<li><img src="data1/images/img3.png" alt="img3" title="img3" id="wows1_2"/></li>
		<li><a href="http://wowslider.net"><img src="data1/images/img4.jpg" alt="jquery slider" title="img4" id="wows1_3"/></a></li>
		<li><img src="data1/images/insuranceheader.jpg" alt="insurance-header" title="insurance-header" id="wows1_4"/></li>
	</ul></div>
<div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">javascript slider</a> by WOWSlider.com v8.8</div>
<div class="ws_shadow"></div>
</div>	
<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
<!-- End WOWSlider.com BODY section -->  
        
            </div>
            </form>
        
    </body>
    
</html>