<html>
<head>
    <title>Show</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <form action="transaction_details.php"method="POST">
        <?php
        include "header.php";
        ?>
        <div class="ldetails">
         <?php
        $noti_id="";
        $noti_details="";
        if(!isset($_POST["submit"]))
        {
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select account_from,account_to,transaction_date,type,mode,amount from transaction_details";
            $result=mysqli_query($con,$sql);
            $table="";
            $table=$table."<table cellpadding='4' border='2'>
            <caption><h1><u> Transaction Details</u></h1></caption>
                
            <tr style='background-color:salmon'>
                
               <th>Account From</th>
                <th>Account To</th>
                   <th>Transaction Date</th>
                  <th>Type</th>
                  <th>Mode</th><th>Amount</th></tr>";
                
        
        while($row=mysqli_fetch_row($result))
        {
            $table=$table."<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td><td>$row[5]</td></tr>";
        }
            $table=$table."</table>";
          echo $table;
            
        }
             else if($_POST["submit"]=="Check")
            {
              $acno=$_POST["txtac"];  
            
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select accountno,sum(amount) from getbalance where accountno='$acno'";
            $result=mysqli_query($con,$sql);
            $table="";
            $table=$table."<table cellpadding='4' border='2'>
            <caption><h1><u>Balance</u></h1></caption>
                
            <tr style='background-color:salmon'>
                
        
                   <th>Account Number</th>
                  <th>Balance</th></tr>";
                
        
        while($row=mysqli_fetch_row($result))
        {
            $table=$table."<tr><td>$row[0]</td><td>$row[1]</td></tr>";
        }
            $table=$table."</table>";
          echo $table;
        }
     
        ?>
        </div>
       
        </form>
   </body>
</html>