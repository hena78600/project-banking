<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <?php
        include"header.php";
    ?>
        
        <h1>Welcome to update Customer Details Page</h1>
    </body>
</html>