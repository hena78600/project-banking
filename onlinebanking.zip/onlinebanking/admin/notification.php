<html>
<head>
    <title>Notification</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
        <form action="notification.php"method="POST">
    <?php
        include"header.php";
    ?>
            <center>
            <div class="login">
                <table>
                    <h2>Notification</h2>
                    <hr/>
                <tr>
                    <td><a href="addnotification.php">Add Notification</a></td>
                    </tr>
                    <tr>
                    <td><a href="shownotification.php">Show Notification</a></td>
                    </tr>
                                  

                </table>
                </div>
            </center>
        
        
            </form>
        
    </body>
    
</html>                
