<html>
<head>
    <title>% interest rate</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
          <?php
        include"header.php";
    ?>
        <form action="addbranch.php"method="POST"> 
 
           <center>
               <div class="login">
               <u><h2>Add ATM Branch</h2></u>
               <table>
               <tr>
               <td>Bank Name</td>
                   <td><input type="text"name="txtnm"></td>
               </tr>
                <tr>
               <td>Branch Name</td>
                   <td><input type="text"name="txtbr"></td>
               </tr>
                <tr>
               <td>Code </td>
                   <td><input type="text"name="txtcd"></td>
               </tr>
                <tr>
               <td>Location</td>
                   <td><input type="text"name="txtloc"></td>
               </tr>
               <tr>
               <td><input type="submit"name="submit"value="Add Branch"</td>
               </tr>
    
            
            
            </table>
               </div>
           </center>
        </form>
         <?php
        if(!isset($_POST["submit"]))
        {
            
        }
        else if($_POST["submit"]=="Add Branch")
        {
            $bnk=$_POST["txtnm"];
            $br=$_POST["txtbr"];
            $code=$_POST["txtcd"];
            $loc=$_POST["txtloc"];
            include "../connect.php";
            $sql="insert into addbranch (bank,branch,code,location) values('$bnk','$br','$code','$loc')";
            mysqli_query($con,$sql);
            mysqli_close($con);
           echo "<h1>Successfully Added"; 
        }
        
        ?>
  
    </body>
    </html>