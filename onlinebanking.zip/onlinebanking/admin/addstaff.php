<html>
<head>
    <title>Add Staff</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
        <form action="addstaff.php"method="POST">
    <?php
        include"header.php";
    ?>
            
            <div class="login">
                
                   <h2><b><u><center>Staff Details</center></u></b></h2>
                    
                <ul>
                    <li>
                    <a href="addstaffmember.php">Add Staff Member</a>
                    </li>
                <li> 
                    <a href="editstaff.php">Edit Staff Member</a>
                    </li>
                    <li>
                    <a href="deletestaff.php">Delete Staff Member</a>
                    
                    </li>
                </ul>
                   
                    

                                </div>
            
        
        
            </form>
        
    </body>
    
</html>                
