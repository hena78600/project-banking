

<?php
$str="";
$str="";
$str=$str."<div id=nav><img src='header_1.jpg' height='130px'width='100%'></img></div>";
$str=$str."<div id='nav1'>";
$str=$str."<div class='navclass'> <a href='adminhome.php'>Home</a></div>";
$str=$str."<div class='navclass'> <a href='addstaff.php'>Staff Details</a></div>";
$str=$str."<div class='navclass'> <a href='view_customer_details.php'>Customer Details</a></div>";


$str=$str."<div class='navclass'><a href='addnotification.php'>Notification</a></div>";

$str=$str."<div class='navclass'><a href='transaction_details.php'>Transaction</a></div>";
$str=$str."<div class='navclass'><a href='balance_details.php'>Balance Details</a></div>";




$str=$str."<div class='navclass'> <a href='approve_atm.php'>ATM/Cheque Book Request</a></div>";
$str=$str."<div class='navclass'> <a href='approve_loan.php'>Approve Loan</a></div>";

$str=$str."<div class='navclass'> <a href='addbranch.php'>Add ATM Branches</a></div>";
$str=$str."<div class='navclass'> <a href='change_password.php'>Change Password</a></div>";
$str=$str."<div class='navclass' style='float:right'> <a href='logout.php'>Logout</a></div>";
$str=$str."</div>";







echo "$str";
