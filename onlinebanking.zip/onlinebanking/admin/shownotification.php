<html>
<head>
    <title>Show</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <form action="shownotification.php"method="POST">
        <?php
        include "header.php";
        ?>
        
         <?php
        $noti_id="";
        $noti_details="";
        if(!isset($_POST["submit"]))
        {
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select notificationid,notificationdetails from addnotification";
            $result=mysqli_query($con,$sql);
            $table="";
            $table=$table."<table cellpadding='4' border='2'>
            <caption><h1><u>Notification Details</u></h1></caption>
            <tr style='background-color:salmon'>
                <th>notification id</th>
                <th>notification Details</th></tr>";
                
        
        while($row=mysqli_fetch_row($result))
        {
            $table=$table."<tr><td>$row[0]</td> <td>$row[1]</td> <td><a href='editnotice.php?nid=$row[0]'>Edit</a></td>
            </tr>";
        }
            $table=$table."</table>";
          echo $table;
        }
        
        
        
        
        
        ?>
        </form>
   </body>
</html>