<html>
<head>
    <title>Add Staff</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <?php
        include"header.php";
    ?>
            <?php
            $name="";
            $deptt="";
            $address="";
             if(!isset($_POST["submit"]))
        {
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select id,login_id,password,name,deptt,address,status from addstaff";
            
            $result=mysqli_query($con,$sql);
            $table="";
            $table=$table."<table border='2'>
            <caption><h1><u>Staff's Details</u></h1></caption>
            <tr style='background-color:salmon'>
            <th>id</th>
            <th>User ID</th>
            <th>Password</th>
            <th> name</th>
            <th> Deptt</th>
            <th>Address</th>
            <th>Status</th></tr>";
            while($row=mysqli_fetch_row($result))
            {
                $table=$table."<tr><td>$row[0]</td>
                <td>$row[1]</td>
                <td>$row[2]</td>
                <td>$row[3]</td>
                <td>$row[4]</td>
                <td>$row[5]</td>
                <td><a href='blockstaff.php?id=$row[0]'>$row[6]</a></td></tr>";
            }
            $table=$table."</table>";
            echo $table;
        }
            
            ?>
    </body>
</html>   