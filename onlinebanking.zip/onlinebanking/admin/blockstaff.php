<html>
<head>
    <title>Block Staff</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    
    <?php
        include"header.php";
    ?>
        <form action="blockstaff.php"method="POST">   
            <?php
            $sid="";
        if(isset($_GET["id"]))
        {
            $sid=$_GET["id"];
            
       include "../connect.php";
            $sql="select id,name,deptt,address,status from addstaff where id='$sid'";
            
            
            
           $result=mysqli_query($con,$sql);
            $table="";
             $table=$table."<h1><u><center>Change Staff's Status</center></u></h1>";
            $table=$table."<table cellpadding='4' style='border:2px solid black' align='center'>";
           
            
            
            while($row=mysqli_fetch_row($result))
            {
                $table=$table."<tr><td>STAFF NAME:</td>
                <td>$row[1]</td></tr>
                <tr><td>DEPTT</td>
                <td>$row[2]</td></tr>
                
                <tr><td>ADDRESS</td>
                <td>$row[3]</td></tr>

                <td>Change Status</td>
                <td><select name='staff_status'><option>Select</option><option>BLOCK</option><option>UNBLOCK</option></td>
                
                <tr><td></td>
                <td><input type='submit' name='submit'value='CHANGE'></td></tr>";
            }
            $table=$table."</table>";
            echo $table;
        }
        
        ?>
                            <input type="hidden"name="hdid"value="<?php echo "$sid"?>">

        </form>
        <?php
    if(!isset($_POST["submit"]))
    {
        
    }
    else if($_POST["submit"]=="CHANGE")
    {
        $staff_id=$_POST["hdid"];
        $status=$_POST["staff_status"];
        include "../connect.php";
        $sql="update addstaff set status='$status' where id=$staff_id";
        mysqli_query($con,$sql);
        mysqli_close($con);
        echo "<h1>Status Changed Successfully</h1>";
    }
    
    
    
    
    
    ?>
    </body>
</html>