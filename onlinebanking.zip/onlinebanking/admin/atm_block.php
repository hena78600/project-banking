<html>
<head>
    <title>Customer's Notification</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    
    <?php
        include"header.php";
    ?>
        <form action="atm_block.php" method="POST">   
            <?php
            $id="";
        if(isset($_GET["id"]))
        {
            $id=$_GET["id"];
            
       include "../connect.php";
            $sql="select id,account_no,request,status from issue where id='$id'";
            
            
            
           $result=mysqli_query($con,$sql);
            $table="";
             $table=$table."<h3><u><center>ATM/Cheque Book Request</center></u></h3>";
            $table=$table."<table cellpadding='4' style='border:2px solid black' align='center'>";
           
            
            
            while($row=mysqli_fetch_row($result))
            {
                $table=$table."<tr><td>Account Number</td>
                <td>$row[1]</td></tr>
                <tr><td>Request</td>
                <td>$row[2]</td></tr>
                
                <tr><td>STATUS</td>
                <td>$row[3]</td></tr>
                <tr>
                <td>Change Status</td>
                <td><select name='atm_status'><option>Select</option><option>APPROVE</option><option>BLOCK</option></td>
                
                <tr><td></td>
                <td><input type='submit' name='submit'value='ALLOW'></td></tr>";
            }
            $table=$table."</table>";
            echo $table;
        }
        
        ?>
        <input type="hidden"name="hdid"value="<?php echo "$id"?>">

        </form>
        <?php
    if(!isset($_POST["submit"]))
    {
        
    }
    else if($_POST["submit"]=="ALLOW")
    {
        $atm_id=$_POST["hdid"];
        $status=$_POST["atm_status"];
        include "../connect.php";
        $sql="update issue set status='$status' where id=$atm_id";
        
        mysqli_query($con,$sql);
        mysqli_close($con);
        echo "<h1>Status Changed Successfully</h1>";
    }
    
    
    
    
    
    ?>
    </body>
    