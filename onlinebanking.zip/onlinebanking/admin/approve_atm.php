<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <?php
        include"header.php";
    ?>
         <?php
        $id="";
        $accno="";
        $request="";
        $status="";
        
        
        if(!isset($_POST["submit"]))
        {
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select id,account_no,request,status from issue";
            $result=mysqli_query($con,$sql);
            $table="";
            $table=$table."<table border='2'>
            <caption><h1><u>Loan Details</u></h1></caption>
            <tr style='background-color:salmon'>
            
            <th>Issue id</th>
        
            <th> Account Number</th>
            <th> Request</th>
            <th>Status</th></tr>";
            while($row=mysqli_fetch_row($result))
            {
                $table=$table."<tr><td>$row[0]</td>
                <td>$row[1]</td>
                <td>$row[2]</td>
                
                <td><a href='atm_block.php?id=$row[0]'>$row[3]</a></td></tr>";
            }
            $table=$table."</table>";
            echo $table;
        }
        
        ?>
       
        
    </body>
</html>