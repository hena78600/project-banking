<html>
<head>
    <title>Add Staff</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <?php
        include"header.php";
    ?>
         <form action="deletestaffmember.php" method="POST">
        
        <?php
        $logid="";
        $pass="";
        $name="";
        $dept="";
        $id="";
        $address="";
        $status="";
        
        if(!isset($_GET["sid"]))
        {
            session_start();
            $login_id=$_SESSION["staff"];
           include "../connect.php";
            $sql="delete from addstaff where login_id='$login_id'";
            mysqli_query($con,$sql);
            mysqli_close($con);
        }
             echo "<h1>Deleted Successfully</h1>";
        ?>
           </form>
        
    </body>
</html>   