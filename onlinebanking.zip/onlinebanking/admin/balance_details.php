<html>
<head>
    <title>Balance Details</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <form action="balance_details.php"method="POST">
    <?php
    include "header.php";
    ?>
    <div class="bcheck">
            <table>
                <h2><b><u><center>Check Balance</center></u></b></h2>
            <tr>
                <td>Enter Account Number</td>
                <td><input type="text"name="txtac"></td>
                <td><input type="submit"name="submit"value="Check"></td>
                </tr>
                
            </table>

         <?php
        $noti_id="";
        $noti_details="";
        if(!isset($_POST["submit"]))
        {
        }
            else if($_POST["submit"]=="Check")
            {
              $acno=$_POST["txtac"];  
            
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select accountno,sum(amount) from getbalance where accountno='$acno'";
            $result=mysqli_query($con,$sql);
            $table="";
            $table=$table."<table cellpadding='4' border='2'>
            <caption><h1><u>Balance</u></h1></caption>
                
            <tr style='background-color:salmon'>
                
        
                   <th>Account Number</th>
                  <th>Balance</th></tr>";
                
        
        while($row=mysqli_fetch_row($result))
        {
            $table=$table."<tr><td>$row[0]</td><td>$row[1]</td></tr>";
        }
            $table=$table."</table>";
          echo $table;
        }  
        ?>
        </div>
    </form>
    </body>
</html>