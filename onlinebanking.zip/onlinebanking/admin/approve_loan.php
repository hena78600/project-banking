<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <?php
        include"header.php";
    ?>
         <?php
        $lid="";
        $accno="";
        $banknm="";
        $branch="";
        $amount="";
        $type="";
        
        if(!isset($_POST["submit"]))
        {
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select loanid,account_no,bankname,branchname,loanamount,loantype,status from loan_details";
            $result=mysqli_query($con,$sql);
            $table="";
            $table=$table."<table border='2'>
            <caption><h1><u>Loan Details</u></h1></caption>
            <tr style='background-color:salmon'>
            
            <th>Loan id</th>
        
            <th> Account Number</th>
            <th>Bank Name</th>
            <th>Branch</th>
            <th>Loan Amount</th>
            <th>Loan Type</th>
            <th>Status</th></tr>";
            while($row=mysqli_fetch_row($result))
            {
                $table=$table."<tr><td>$row[0]</td>
                <td>$row[1]</td>
                <td>$row[2]</td>
                <td>$row[3]</td>
                <td>$row[4]</td>
                <td>$row[5]</td>
                
                
                <td><a href='loan_block.php?lid=$row[0]'>$row[6]</a></td></tr>";
            }
            $table=$table."</table>";
            echo $table;
        }
        
        ?>
    
    </body>
</html>