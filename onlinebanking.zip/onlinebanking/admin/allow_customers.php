<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <?php
        include"header.php";
    ?>
        
        <h1>Welcome to allow customer Page</h1>
    </body>
</html>