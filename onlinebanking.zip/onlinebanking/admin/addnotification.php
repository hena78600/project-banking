<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
        <form action="addnotification.php" method="POST">
    <?php
        include"header.php";
    ?>
            <center>
                <div class="login">
        <table>
            <h2><b><u>Add New Notification</u></b></h2>
        <tr>
            <td>Add Notification</td>
            <td><textarea rows="4" cols="5"name="txtnoti"></textarea></td>
            </tr>
            <tr>
            <td><input type="submit"name="submit"value="Add"></td>
            </tr>
            <tr>
            <td><a href="shownotification.php">Edit Notification</a></td>
            </tr>
        </table>
                </div>
            </center>
              </form>
     <?php
        if(!isset($_POST["submit"]))
        {
            
        }
        else if($_POST["submit"]=="Add")
        {
            $addnotification=$_POST["txtnoti"];
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="insert into addnotification(notificationdetails) values('$addnotification')";
            mysqli_query($con,$sql);
            mysqli_close($con);
            echo "Data saved Successfully";
        }
        ?>
    </body>
        
      </html>