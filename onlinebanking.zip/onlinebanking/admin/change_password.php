<html>
<head>
    <title>Show</title>
    <link rel="stylesheet"type="text/css"href="adminstyle.css">
    </head>
    <body>
    <div class="left">
        <?php
        include "header.php";
        ?>
        </div>
        <div class="right">
                    <form action="change_password.php"method="POST">

            <div class="login">
        <table>
            <h1><u><center>CHANGE PASSWORD</center></u></h1>
        
        <tr>
            <td>New Password</td>
            <td><input type="password"name="txtnewpass"></td>
            </tr>
            <tr>
            <td>Confirm Password</td>
            <td><input type="password"name="txtconpass"></td>
            </tr>
            <tr>
            <td><input type="submit"name="submit"value="CHANGE"></td>
            </tr>
        </table>
                        </div>
                </form>
            </div>
            
                
        
         <?php
      
        if(!isset($_POST["submit"]))
            
        {
        }
        else if($_POST["submit"]=="CHANGE")
        {
            $npass=$_POST["txtnewpass"];
             $conpass=$_POST["txtconpass"];
            
            session_start();
            $aid=$_SESSION["u"];
            
            
            $con=mysqli_connect("localhost","root","","netbanking");
            if(strcmp($npass,$conpass)==0)
            {
            $sql="update adminlogin set password='$npass' where userid='$aid' and password='$aid'";
            mysqli_query($con,$sql);
            mysqli_close($con);
echo "<h1>password change Successfully</h1> ";
            }
            else
            {
                echo "<h1>confirm password mismatch</h1>";
            }
            
            
            
            
        }
        
        
        ?>
        </form>
   </body>
</html>