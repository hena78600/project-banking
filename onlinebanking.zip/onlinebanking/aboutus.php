<html>
<head>
    <title>About Us</title>
    <link rel="stylesheet"type="text/css"href="style.css">
    </head>
    <body>
    <?php
        
      include"header.php";  
    
    ?>
        
         <center>
            <div id="contact">
                <center>
                    <h1><u><center><font color="blue">About Us</font></center></u></h1>
                    <p><b><font color="blue">Internet Banking :</font></b>Internet Banking is a full service facility that allow you to do your banking with complete security from the comfort and safety of your home or office.There feature and 
                    benefit are available in our system are as follows.</p>
                    <p><b><font color="blue">Features and Benefits </font></b></p>
                    <p><b><font color="blue">Prepaid :</font></b>Prepaid top up available from your mobile device or computer anywhere anytime.You never have to worried about running out of your prepaid purchases.</p>
                    <p><b><font color="blue">Balance Inquiry :</font></b>View the latest balance on all account linked to your netBank profile, instead of waiting for the post visiting the ATM or going into branch, you can now conveniently log into your internet or mobile bank profile from your phone,tablet or computer.</p>
                    <p><b><font color="blue">Investment :</font></b>Investment account holder with netbank can now freely access their information on Netbank without needing a linked netbank transactional account.Netbank investment account holder now have the convenience to freely view their entire list of statement and account balance online.</p>
                    <p><b><font color="blue">Loan :</font></b>Account Holder can apply for any type of loans like Home Loan, Car loan, Gold Loan etc.</p>
                </center>
             </div>
    </body>
    
</html>