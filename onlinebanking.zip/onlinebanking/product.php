<html>
<head>
    <title>% interest rate</title>
    <link rel="stylesheet"type="text/css"href="style.css">
    </head>
    <body>
       <form action="interest.php"method="POST"> 
    <?php
        include"header.php";
    ?>
        
        <div id="interest">
    
                <h1><u><b><font color="pink">Our Online Services</font></b></u></h1>
                
                
                    <h2><b>Loan Types</b></h2>
                    <ul>
                <li>Home Loan</li>
                <li>Car Loan</li>
                <li>Gold Loan</li></ul>
                   <h2><b>Online Banking</b></h2>
                <p><b><font color="blue">Internet Banking :</font></b>Internet Banking is a full service facility that allow you to do your banking with complete security from the comfort and safety of your home or office.There feature and 
                    benefit are available in our system are as follows.</p>
                     <p><b><font color="blue">Investment :</font></b>Investment account holder with netbank can now freely access their information on Netbank without needing a linked netbank transactional account.Netbank investment account holder now have the convenience to freely view their entire list of statement and account balance online.</p>
                   <p><b><font color="blue">Insurance : </font></b>We provide various types of Insurance Like SBI Life Insurance, HDFC Life Insurance.</p>
            
    
           </div>
        
        </form>
    </body>
    
</html>
