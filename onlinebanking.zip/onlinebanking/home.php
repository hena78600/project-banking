<html>
<head>
    <title>Visitor's Home Page</title>
    <link rel="stylesheet" type="text/css"href="style.css">
 <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
    
    <?php
        include "header.php";
        ?>
        <div class="slide">
            
           <!-- Start WOWSlider.com BODY section -->
<div id="wowslider-container1">
<div class="ws_images"><ul>
		<li><img src="data1/images/banner01.jpg" alt="banner01" title="banner01" id="wows1_0"/></li>
		<li><img src="data1/images/img1.jpg" alt="img1" title="img1" id="wows1_1"/></li>
		<li><a href="http://wowslider.net"><img src="data1/images/img2.jpg" alt="jquery image slider" title="img2" id="wows1_2"/></a></li>
		<li><img src="data1/images/img3.png" alt="img3" title="img3" id="wows1_3"/></li>
	</ul></div>
<div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">javascript slider</a> by WOWSlider.com v8.8</div>
<div class="ws_shadow"></div>
</div>	
<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
<!-- End WOWSlider.com BODY section --> 
    </div>
    
    
    </body>
</html>