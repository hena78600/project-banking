<html>
<head>
    <title>Contact Us</title>
    <link rel="stylesheet"type="text/css"href="style.css">
    </head>
    <body>
    <?php 
      include"header.php";    
    ?>
    
    
                   <marquee direction="left"  scrollamount="3">
                       <p><h3><font color="orange">Latest News</font><font color="green"> : Bank has launched new skill loan scheme for providing loan facility | No need to issue cheques by investors while subscribing for IPO. Just write the Bank account number and sign in application form to authorize your bank to make your payment</font></h3></p>
                       </marquee>
        <center>
            <table border="2"solid black>
                <h2><b><u>NOTICE</u></b></h2>
                <tr><td>
                    <h3> <p><li>KYC is one time exercise while dealing in security markets, once KYC is done through the customer</li></p></h3></td></tr>
                <tr>
                    <td><h3> <p><li>Prevent Unauthorized transaction in your account, Update your Mobile Number.</li></p></h3>
                </td>
                </tr>
                <tr>
                <td>
                    <h3><p><li>Phishing is a fraudulent attempt, usually made through email,phone calls,SMS etc. seeking your<br> personal and confidential information</li></p></h3>
       
                    </td>
                </tr>
                <tr>
                <td>
                    <h3> <p><li>Online Bank or its representative never sends you mail or SMS or calls over your phones to get our<br> personal information, password or one time SMS(high security) password.</li></p></h3>
        
                    </td>
                </tr>
      <tr>
                <td>
                    <h3> <p><li>Any such email or SMS or phone call is an attempt to frauduently withdraw money from your account through internet<br> Banking. Never response to such email,SMS or phone calls.Please report immediately if you get any email SMS<br> or phone calls and lock your user access immediately.</li></p></h3>
      
          </td>
                </tr>          
                
        
        </table>
        </center>
    
     
        
        
    </body>
    
</html>