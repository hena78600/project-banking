<?php
$str="";
$str=$str."<div id='nav'>";
$str=$str."<div class='navclass'><a href='contact.php'>Contact Us</a></div>";

$str=$str."<div class='navclass'><a href='aboutus.php'>About Us | </a></div>";

$str=$str."<div class='navclass'><a href='home.php'>Home | </a></div>";

$str=$str."</div>";
$str=$str."<div id=nav1><img src='banking.jpg' height='130px'width='100%'></img></div>";

$str=$str."<div id='navid'>";
$str=$str."<div class='navcls'><a href='notice.php'>Notice</a></div>";
$str=$str."<div class='navcls'><a href='interest.php'>% Interest Rate</a></div>";
$str=$str."<div class='navcls'><a href='applicationform.php'> Apply Online</a></div>";
$str=$str."<div class='navcls'><a href='product.php'>Product and Services</a></div>";

$str=$str."<div class='navcls'><a href='findatm.php'>Find ATM/Branch</a></div>";

$str=$str."<div class='navcls'><a href='adminlogin.php'>Admin Login</a></div>";

$str=$str."<div class='navcls'><a href='customer_login.php'>Customer Login</a></div>";
$str=$str."</div>";




echo "$str";




?>