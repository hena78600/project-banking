<html>
<head>
    <title>change Password</title>
    <link rel="stylesheet"type="text/css"href="cstyle.css">
    </head>
    <body>
        <form action="change_password.php"method="POST">
    <?php
        include"header.php";
    ?>
            <center>
            <div class="login">
            
            <table>
                <h1><u><center>CHANGE PASSWORD</center></u></h1>
            
                 <tr>
                <td>Enter Old Password</td>
                <td><input type="password"name="txtold"></td>
                </tr>
           
            <tr>
                <td>Enter New Password</td>
                <td><input type="password"name="txtnew"></td>
                </tr>
                <tr>
                <td>Confirm Password</td>
                <td><input type="password"name="txtcon"></td>
                </tr>
                <tr>
                <td><input type="submit"name="submit"value="Change"></td>
                </tr>
            
            </table>
            </div>
            </center>
            <?php
            if(!isset($_POST["submit"]))
            {
                
            }
            else if($_POST["submit"]=="Change")
            {
        
                $newpass=$_POST["txtnew"];
                $conpass=$_POST["txtcon"];
                
                session_start();
                $new=$_SESSION["user"];
                
                $con=mysqli_connect("localhost","root","","netbanking");
                if(strcmp($newpass,$conpass)==0)
                {
                    $sql="update registration set password='$newpass' where email='$new'";
                    mysqli_query($con,$sql);
                    mysqli_close($con);
                    echo "password changed successfully";
                    
                }
                else
                {
                echo "Confirm Password Missmatch";
                }
            }
            
            
            
            
        ?>
        
            </form>
        
    </body>
    
</html>