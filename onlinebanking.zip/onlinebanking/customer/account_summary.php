<html>
<head>
    <title>Account Summary</title>
    <link rel="stylesheet"type="text/css"href="cstyle.css">
    </head>
    <body style="background-image:url('tree.jpg');background-repeat:no-repeat;background-size:cover;">
        
        <form action="account_summary.php"method="POST">
    <?php
        include"header.php";
    ?>
        <?php
        if(!isset($_POST["submit"]))
           {
               session_start();
               $email=$_SESSION["user"];
               $con=mysqli_connect("localhost","root","","netbanking");
               $sql="select name,bankname,branch,type,account_no,(select SUM(amount)from getbalance where accountno=registration.account_no)as balance,(SELECT max(transaction_date) FROM transaction_details where account_to=registration.account_no)as tdate FROM registration where email='$email'";
               $result=mysqli_query($con,$sql);
               $table="";
                $table=$table."<table style='background-color:salmon;border:2px solid black'>
                <caption><h1><u>Account Summary</u></h1></caption>";
            while($row=mysqli_fetch_row($result))
            {
             $table=$table."<tr><td>Name</td>
               <td>$row[0]</td></tr>
               <tr><td>Bank Name</td>
               <td>$row[1]</td></tr>
               <tr><td>Branch</td>
               <td>$row[2]</td></tr>
               <tr><td>Type Of Account</td>
               <td>$row[3]</td></tr>
               
               <tr><td>Account Number</td>
               <td>$row[4]</td></tr>
               
               <tr><td>Available Balance </td>
               <td>$row[5]</td></tr>
               
               <tr><td>Last Transaction Date</td>
               <td>$row[6]</td></tr> ";
           }
             $table=$table."</table>";
            echo $table;
           }
            
            ?>
        
            </form>
        
    </body>
    
</html>