<html>
<head>
    <title>Edit Personal Profile</title>
    <link rel="stylesheet"type="text/css"href="cstyle.css">
    </head>
    <body>
        <?php
        include "header.php";
        
        ?>
            <form enctype="multipart/form-data"  action="edit_profile.php"method="POST">

         <?php
        $id="";
        $name="";
        $fname="";
        $gender="";
        $ano="";
        $mno="";
        $email="";
        $dob="";
        $add="";
        $bank="";
        $branch="";
        $type="";
        $image="";
        if(isset($_GET["eid"]))
        {
            $eid=$_GET["eid"];
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select name,fname,gender,adhaar,mobile,email,dob,address,bankname,branch,type,image from registration where email='$eid'";
            
            $result=mysqli_query($con,$sql);
            while($row=mysqli_fetch_row($result))
        {
                
                $name=$row[0];        
                $fname=$row[1];     
                $gender=$row[2];  
                $ano=$row[3];  
                $mno=$row[4];  
                $email=$row[5];  
                $dob=$row[6];  
                $add=$row[7];  
                $bank=$row[8];  
                $branch=$row[9];  
                $type=$row[10];  
                $image=$row[11];  
        }
            
            mysqli_close($con);
        }
        ?>
        <table>
            <tr>
            <td><input type="hidden"name="txthidden" value="<?php echo $id;?>"></td>
            </tr>
            
        <tr>
            <td>Name</td>
            <td><input type="text"name="txtname" value="<?php echo $name; ?>">  </td>
            </tr>
            
        <tr>
            <td>Father Name</td>
            <td><input type="text"name="f" value="<?php echo $fname; ?>">  </td>
            </tr>
            
        <tr>
            <td>Gender</td>
            <td><input type="radio"name="gen" <?php if($gender=="Male") echo "checked"; ?> value="Male">Male
                <input type="radio"name="gen" <?php if($gender=="Female") echo "checked"; ?> value="Female">Female
                
                  </td>
            </tr>
            
        <tr>
            <td>Adhaar Number</td>
            <td><input type="text"name="a" value="<?php echo $ano; ?>">  </td>
            </tr>
            
        <tr>
            <td>Mobile Number</td>
            <td><input type="text"name="m" value="<?php echo $mno; ?>">  </td>
            </tr>
            
        <tr>
            <td>Date of Birth</td>
            <td><input type="date"name="dob" value="<?php echo $dob; ?>">  </td>
            </tr>
            
        <tr>
            <td>Address</td>
            <td><input type="text"name="add" value="<?php echo $add; ?>">  </td>
            </tr>
            
        <tr>
            <td>Bank Name</td>
            <td><input type="text"name="bank" value="<?php echo $bank; ?>">  </td>
            </tr>
            
        <tr>
            <td>Branch</td>
            <td><input type="text"name="br" value="<?php echo $branch; ?>">  </td>
            </tr>
            
        <tr>
            <td>Type</td>
            <td><select name="type" ><option><?php echo $type?></option>  
                <option>Current</option>
                <option>Saving</option>
                </select> 
            </td>
            </tr>
            
        <tr>
            <td>Image</td>
            <td><input type="file"name="img"> <?php echo $image; ?> </td>
            
            </tr>
        <tr><td><input type="submit"name="submit" value="Update"></td>
            </tr>
        
        
        </table>
        </form>
        <?php
        if(!isset($_POST["submit"]))
        {
            
        }
    else if($_POST["submit"]=="Update")
    {
        session_start();
        $email=$_SESSION["user"];
        
        $hidden_id=$_POST["txthidden"];
        $name=$_POST["txtname"];
        $fname=$_POST["f"];
        $gen=$_POST["gen"];
        $ad=$_POST["a"];
        $mob=$_POST["m"];
        $dob=$_POST["dob"];
        $add=$_POST["add"];
        $bnk=$_POST["bank"];
        $br=$_POST["br"];
        $type=$_POST["type"];
        
         $img=$_FILES["img"]["name"];
            $temp_image=$_FILES["img"]["tmp_name"];
            move_uploaded_file($temp_image,$img);
            
        include "../connect.php";
        $sql="update registration set name='$name',fname='$fname',gender='$gen',adhaar='$ad',mobile='$mob',dob='$dob',address='$add',bankname='$bnk',branch='$br',type='$type',image='$img' where email='$email'";
        mysqli_query($con,$sql);
        mysqli_close($con);
        
        echo "<h1> Profile Updated Successfully</h1>";
    }
        
        
        
        
        ?>
   </body>
</html>