<html>
<head>
    <title>Issue ATM/Cheque Book</title>
    <link rel="stylesheet"type="text/css"href="cstyle.css">
    </head>
    <body>
        <?php
        include "header.php";
        ?>
        <?php
            $accno="";
            session_start();
            $email=$_SESSION["user"];
            include "../connect.php";
            $sql="select account_no from registration where email='$email'";
            $result=mysqli_query($con,$sql);
            while($row=mysqli_fetch_row($result))
             {
                $accno=$row[0];
                
                
            }
            mysqli_close($con);
            ?>
            
        
        
        
        <?php
        $accno="";
        $req="";
        
        $atm_status="";
        $ch_status="";

        $email=$_SESSION["user"];
        include "../connect.php";
        $sql="SELECT account_no,(select status from issue where request='ATM' and account_no=registration.account_no ORDER BY id DESC LIMIT 1)as atmrequest, (select status from issue where request='Cheque Book' and account_no=registration.account_no ORDER BY id DESC LIMIT 1)AS chequebook from registration where email='$email'";
        $result=mysqli_query($con,$sql);
        $res="";
        while($row=mysqli_fetch_row($result))
        {
        
            $accno=$row[0];
            $atm_status=$row[1];
            $ch_status=$row[2];
        }
        mysqli_close($con);
        
        
        ?>
        <form action="issueatm.php"method="POST">
            <center>
                <div class="login">
                
         <table border="5px solid black">
             <h2><b><u><center>Reuest For ATM/Cheque Book</center></u></b></h2>
            <tr style='background-color:salmon' align='center' >
                <th>ATM Card Request</th>
             </tr>
             
            <tr>
                <td align="center">Status</td>
                <td><?php echo "$atm_status"; ?></td>
                <td><input type="submit"name="submit" value="Request ATM"></td>
             </tr>
             
             
             
            <tr style='background-color:salmon' align='center'>
             <th>Cheque Book Request</th>
             </tr>
             <tr>
                <td align="center">Status</td>
                 <td><?php echo "$ch_status"; ?></td>
               <td><input type="submit"name="submit" value="Request Cheque Book"></td>
             </tr>
            <tr>
             <td><input type="hidden" name="hdac" value="<?php echo "$accno";?>"></td>
             </tr>
            </table>
                </div>
            </center>
               </form>
        
          <?php
        if(!isset($_POST["submit"]))
        {
            
        }
        else if($_POST["submit"]=="Request ATM")
        {
            $accountno=$_POST["hdac"];
    
             $con=mysqli_connect("localhost","root","","netbanking");
            $sql="insert into issue (account_no,request,status) values('$accountno','ATM','PENDING')";
            mysqli_query($con,$sql);
            mysqli_close($con);
            echo "<h1>Requested For the ATM</h1>";
           }
        else if($_POST["submit"]=="Request Cheque Book")
        {
            $accountno=$_POST["hdac"];
    
             $con=mysqli_connect("localhost","root","","netbanking");
            $sql="insert into issue (account_no,request,status) values('$accountno','Cheque Book','PENDING')";
            mysqli_query($con,$sql);
            mysqli_close($con);
            echo "<h1>Requested For the Cheque Book</h1>";
           }
        
        ?>
            
        
    
    </body>
</html>