

<?php
$str="";
$str=$str."<div id=nav><img src='header_1.jpg' height='130px'width='100%'></img></div>";
$str=$str."<div id='nav1'>";
$str=$str."<div class='navclass'> <a href='home.php'>Home</a></div>";

$str=$str."<div class='navclass'> <a href='view_profile.php'>Personal Profile</a></div>";
$str=$str."<div class='navclass'> <a href='transaction.php'>Transaction</a></div>";
$str=$str."<div class='navclass'> <a href='view_notification.php'>View Notification</a></div>";
$str=$str."<div class='navclass'> <a href='issueatm.php'>Issue ATM Card/Cheque Book</a></div>";
$str=$str."<div class='navclass'> <a href='account_summary.php'>Account Summary</a></div>";
$str=$str."<div class='navclass'> <a href='apply_loan.php'>Apply For Loan</a></div>";

$str=$str."<div class='navclass'> <a href='change_password.php'>Change Password</a></div>";
$str=$str."<div class='navclass'> <a href='logout.php'>Logout</a></div>";

$str=$str."</div>";

echo "$str";
?>