<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"type="text/css"href="cstyle.css">
    </head>
    <body>
        <form action="transfer_funds.php"method="POST">
    <?php
        include"header.php";
            
     
    ?>
        
        <h1>Welcome to Transfer Page</h1>
            </form>
        
    </body>
    
</html>