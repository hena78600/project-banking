<html>
<head>
    <title>Transaction</title>
     <link rel="stylesheet"type="text/css"href="cstyle.css">
   
    </head>
    <body style="background-image:url('coin.jpg');background-repeat:no-repeat;background-size:cover;">
        
        <form action="transaction.php"method="POST">
    <?php
        include "header.php";
        ?>
            <?php
            $accno="";
            session_start();
            $email=$_SESSION["user"];
            include "../connect.php";
            $sql="select account_no from registration where email='$email'";
              $result=mysqli_query($con,$sql);
            while($row=mysqli_fetch_row($result))
             {
                $accno=$row[0]; 
            }
            mysqli_close($con);
            ?>
            
           <div class="login">
                <u><h1>TRANSACTION</h1></u>
               <table>
                   
                <tr>
                    <td><input type="hidden"name="txtac" value="<?php echo $accno;?>"></td>
                   </tr>
                   <tr>
                   <td>Account To</td>
                       <td><input type="text"name="txtacto"></td>
                   </tr>
                   <tr>
                   <td>Transaction Date</td>
                       <td><input type="date"name="tdate"></td>
                   </tr>
                   <tr>
                   <td>Type</td>
                   <td><select name="type"><option>Select</option><option>Withdraw</option>
                       <option>Deposit</option>
                       <option>Transfer</option></select></td>
                   </tr>
                <tr>
                   <td>Mode</td>
                   <td><select name="mode"><option>Select</option><option>Cash</option>
                       <option>Cheque</option>
                       <option>NEFT</option></select></td>
                   </tr>
                <tr>
                   <td>Amount</td>
                   <td><input type="text"name="txtamt"></td>
                   </tr>
                   <tr>
                   <td><input type="submit"name="submit"value="SUBMIT"></td>
                   </tr>
        
                </table>
            </div>
                
        </form>
            <?php
        if(!isset($_POST["submit"]))
        {
            
        }
        else if($_POST["submit"]=="SUBMIT")
        {       
            
            $acfrom=$_POST["txtac"];
            
            $acto=$_POST["txtacto"];
            
            $trandate=$_POST["tdate"];
            $type=$_POST["type"];
            $mode=$_POST["mode"];
            $amount=$_POST["txtamt"];
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="insert into transaction_details(account_from,account_to,transaction_date,type,mode,amount)values('$acfrom','$acto','$trandate','$type','$mode',$amount)";
            mysqli_query($con,$sql);
            mysqli_close($con);
            echo "<h1>Transaction Successful</h1>";             
        }
            
            
            
            
          ?>