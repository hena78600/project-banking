<html>
<head>
    <title>Issue ATM/Cheque Book</title>
    <link rel="stylesheet"type="text/css"href="cstyle.css">
    </head>
    <body>
        <form action="issueatm.php"method="POST">
    <?php
        include "header.php";
        ?>
            <div class="login">
                <table border="3px"solid black>
                <tr>
                <td>Issue: </td>
                <td><select name="issue">
                    <option>Select</option>
                    <option>ATM Card</option>
                    <option>Cheque Book</option>
                    </select></td>
                </tr>
                    <tr>
                    <td><input type="submit"name="submit" value="Request"></td>
                    </tr>
            </table>
            </div>
                </form>
                <br>
        
    </body>
</html>