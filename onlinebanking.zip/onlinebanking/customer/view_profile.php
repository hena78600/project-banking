<html>
<head>
    <title>Personal Profile</title>
    <link rel="stylesheet"type="text/css"href="cstyle.css">
    </head>
    <body>
        
    <?php
        include"header.php";
    ?>
            
        
          <?php  
        if(!isset($_POST["submit"]))
        {
            session_start();
            
           $email=$_SESSION["user"];
        $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select distinct id,name,fname,gender,adhaar,mobile,email,dob,address,bankname,branch,type,image from registration where email='$email'";
            $result=mysqli_query($con,$sql);
            $table="";
              $table=$table."<table style='background-color:salmon;border:2px solid black'>
            <caption><h1><u>Personal Details</u></h1></caption>";
            while($row=mysqli_fetch_row($result))
            {
                $table=$table."<tr><td>Name</td>
                <td>$row[1]</td></tr>
                <tr><td>Father Name</td>
                <td>$row[2]</td>
                   <tr><td>Gender</td>
                <td>$row[3]</td>
                <tr><td>Adhaar Number</td>
                <td>$row[4]</td>
                <tr><td>Mobile Number</td>
                <td>$row[5]</td>
                <tr><td>Email ID</td>
                <td>$row[6]</td>
                 <tr><td>Date Of Birth</td>
                <td>$row[7]</td>
                 <tr><td>Address</td>
                <td>$row[8]</td>
                <tr><td>Bank Name</td>
                <td>$row[9]</td>
                 <tr><td>Branch</td>
                <td>$row[10]</td>
                 <tr><td>Type Of Account</td>
                <td>$row[11]</td>
                <tr><td>Image</td>
                <td>$row[12]</td></tr><tr><td><center><a href='edit_profile.php?eid=$row[6]'>EDIT</a></center></td></tr>";
               }
                        
            $table=$table."</table>";
            echo $table;
        }
    
        mysqli_close($con);
        ?>
    </body>
    
</html>