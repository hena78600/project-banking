<html>
<head>
    <title>Issue ATM/Cheque Book</title>
    <link rel="stylesheet"type="text/css"href="cstyle.css">
    </head>
    <body>
        <form action="issueatm.php"method="POST">
    <?php
        include "header.php";
        ?>
            <div class="login">
                <table border="3px"solid black>
                <tr>
                <td>Issue: </td>
                <td><select name="issue">
                    <option>Select</option>
                    <option>ATM Card</option>
                    <option>Cheque Book</option>
                    </select></td>
                </tr>
            </table>
                <br>
            <table border="3px"solid black>
            <tr>
                <th>Requests</th>
                <th>Status</th>
                </tr>
                <tr>
                <td>ATM Card Status</td>
                    <td><a href="approve_atm.php">Edit</a></td>
                </tr>
                <tr><td>Cheque Book Status</td>
                <td><a href="approve_cheque.php">Edit</a></td>
                </tr>
            </table>
            </div>
        </form>
    </body>
</html>