<html>
<head>
    <title>Show</title>
    <link rel="stylesheet"type="text/css"href="cstyle.css">
    </head>
    <body>
    <form action="view_notification.php"method="POST">
        <?php
        include "header.php";
        ?>
        
         <?php
        $noti_id="";
        $noti_details="";
        if(!isset($_POST["submit"]))
        {
            $con=mysqli_connect("localhost","root","","netbanking");
            $sql="select notificationdetails from addnotification";
            $result=mysqli_query($con,$sql);
            $table="";
            $table=$table."<table cellpadding='4' border='2'>
            
            <tr style='background-color:salmon'>
                
                <th>notification Details</th></tr>";
                
        
        while($row=mysqli_fetch_row($result))
        {
            $table=$table."<tr><td>$row[0]</td></tr>";
        }
            $table=$table."</table>";
          echo $table;
        }
        
        
        
        
        
        ?>
        </form>
   </body>
</html>