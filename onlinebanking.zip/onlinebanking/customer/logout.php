<html>
<head>
    <title>Logout</title>
    <link rel="stylesheet"type="text/css"href="style.css">
    </head>
    <body>
        <form action="logout.php"method="POST">
    <?php
        include"header.php";
    ?>
            <?php
          session_start();
            $_SESSION["user"];
            header("location:../customer_login.php");
            echo "<h1>Welcome to logout Page</h1>";
        ?>
            </form>
        
    </body>
    
</html>