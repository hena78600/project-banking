<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"type="text/css"href="style.css">
    </head>
    <body>
        <form action="deposit.php"method="POST">
    <?php
        include"header.php";
            
     
    ?>
        
        <h1>Welcome to deposit Page</h1>
            </form>
        
    </body>
    
</html>