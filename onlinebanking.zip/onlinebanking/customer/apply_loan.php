<html>
<head>
    <title>Loan</title>
    <link rel="stylesheet"type="text/css"href="cstyle.css">
    </head>
    <body style="background-image:url('schemes.jpg');background-repeat:no-repeat;background-size:cover;">
        
        <form action="apply_loan.php"method="POST">
    <?php
        include"header.php";
    ?>
            <?php
            $accno="";
            session_start();
            $email=$_SESSION["user"];
            include "../connect.php";
            $sql="select account_no from registration where email='$email'";
            $result=mysqli_query($con,$sql);
            while($row=mysqli_fetch_row($result))
             {
                $accno=$row[0];
                
                
            }
            mysqli_close($con);
            ?>
            
    
            <div class="login">
                <table>
                    <h1><u>Apply For Loan</u></h1>
                 <tr>
                   
                     <td><input type="hidden"name="hdac" value="<?php echo $accno; ?>"></td>
                   </tr>
                   <tr>
                   <td>Name of Bank</td>
                       <td><input type="text"name="txtname"></td>
                   </tr>
                   <tr>
                   <td>Branch</td>
                       <td><input type="text"name="branch"></td>
                   </tr>
                    <tr>
                     <td>Loan Amount</td>
                       <td><input type="text"name="loanamt"></td>
                   </tr>
                  
                   <tr>
                   <td>Loan Type</td>
                   <td><select name="type"><option>Select</option><option>Car Loan</option>
                       <option>Home Loan</option>
                       <option>Gold Loan</option></select></td>
                   </tr>
                
               <tr>
                    <td><input type="submit"name="submit"value="SUBMIT"></td>
                    </tr>
                
                </table>
                
                </div>
            
            
           
            
                  <?php
        if(!isset($_POST["submit"]))
        {
            
        }
        else if($_POST["submit"]=="SUBMIT")
        {
            $accno=$_POST["hdac"];
            $banknm=$_POST["txtname"];
            $branch=$_POST["branch"];
            $amt=$_POST["loanamt"];
            $type=$_POST["type"];
            
            
             $con=mysqli_connect("localhost","root","","netbanking");
            $sql="insert into loan_details(account_no,bankname,branchname,loanamount,loantype,status) values('$accno','$banknm','$branch',$amt,'$type','PENDING')";
        
            mysqli_query($con,$sql);
            mysqli_close($con);
            echo "<h1> Successful submitted</h1>";             
        }  
             ?>
            </form>
    </body>
</html>