

<?php
$str="";
$str=$str."<div id=nav><img src='header_1.jpg' height='130px'width='100%'></img></div>";
$str=$str."<div id='nav1'>";
$str=$str."<div class='navclass'> <a href='home.php'>Home</a></div>";

$str=$str."<div class='navclass'> <a href='view_profile.php'>Personal Profile</a></div>";
$str=$str."<div class='navclass'> <a href='transaction.php'>Loan Request</a></div>";
$str=$str."<div class='navclass'> <a href='view_notification.php'>ATM Approval Request</a></div>";
$str=$str."<div class='navclass'> <a href='issueatm.php'>Cheque Book Request</a></div>";

$str=$str."<div class='navclass'> <a href='change_password.php'>Change Password</a></div>";
$str=$str."<div class='navclass'> <a href='logout.php'>Logout</a></div>";

$str=$str."</div>";

echo "$str";
?>







