<html>
<head>
    <title>Home Page</title>
    <link rel="stylesheet"type="text/css"href="sstyle.css">
    </head>
    <body>
        <form action="home.php"method="POST">
    <?php
        include"header.php";
    ?>
            <div class="lwel">
                <center><table><tr><td>Welcome</td></tr></table></center>
           </div>
            <div class="rimage">
            <img src="OnlineBanking4.jpg" height="250px"width="500px">
            </div>
       
    
        </form>
        
    </body>
    
</html>
