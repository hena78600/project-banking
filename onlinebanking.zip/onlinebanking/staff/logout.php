<html>
<head>
    <title>Logout</title>
    <link rel="stylesheet"type="text/css"href="sstyle.css">
    </head>
    <body>
        <form action="logout.php"method="POST">
    <?php
        include"header.php";
    ?>
            <?php
          session_start();
            $_SESSION["staff"];
            header("location:../staff_login.php");
            echo "<h1>Welcome to logout Page</h1>";
        ?>
            </form>
        
    </body>
    
</html>