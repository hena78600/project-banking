<html>
<head>
    <title>change Password</title>
    <link rel="stylesheet"type="text/css"href="sstyle.css">
    </head>
    <body>
        <form action="change_password.php"method="POST">
    <?php
        include"header.php";
    ?>
            <center>
            <div class="login">
            
            <table>
                <h1><center>CHANGE PASSWORD</center></h1>
            <hr/>
            <tr>
                <td>Enter New Password</td>
                <td><input type="text"name="txtnew"></td>
                </tr>
                <tr>
                <td>Confirm Password</td>
                <td><input type="text"name="txtcon"></td>
                </tr>
                <tr>
                <td><input type="submit"name="submit"value="Change"></td>
                </tr>
            
            </table>
            </div>
            </center>
            <?php
            if(!isset($_POST["submit"]))
            {
                
            }
            else if($_POST["submit"]=="Change")
            {
        
                $newpass=$_POST["txtnew"];
                $conpass=$_POST["txtcon"];
                
                session_start();
                $new=$_SESSION["staff"];
                
                $con=mysqli_connect("localhost","root","","netbanking");
                if(strcmp($newpass,$conpass)==0)
                {
                    $sql="update addstaff set password='$newpass' where login_id='$new'";
                    mysqli_query($con,$sql);
                    mysqli_close($con);
                    echo "password changed successfully";
                    
                }
                else
                {
                echo "Confirm Password Missmatch";
                }
            }
            
            
            
            
        ?>
        
            </form>
        
    </body>
    
</html>